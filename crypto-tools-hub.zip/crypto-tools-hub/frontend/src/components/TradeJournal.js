import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { PlusCircle, TrendingUp, TrendingDown } from 'lucide-react';
import { toast } from 'sonner';

export const TradeJournal = ({ api }) => {
  const [trades, setTrades] = useState([]);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    entry_price: '',
    stop_loss: '',
    take_profit: '',
    result: 'win'
  });

  const fetchTrades = async () => {
    try {
      const response = await axios.get(`${api}/trades`);
      setTrades(response.data);
    } catch (error) {
      console.error('Error fetching trades:', error);
      toast.error('Failed to load trades');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTrades();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.entry_price || !formData.stop_loss || !formData.take_profit) {
      toast.error('Please fill all fields');
      return;
    }

    try {
      await axios.post(`${api}/trades`, formData);
      toast.success('Trade logged successfully');
      setFormData({
        entry_price: '',
        stop_loss: '',
        take_profit: '',
        result: 'win'
      });
      fetchTrades();
    } catch (error) {
      console.error('Error creating trade:', error);
      toast.error('Failed to log trade');
    }
  };

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Form Section */}
      <div className="lg:col-span-1">
        <div className="border border-terminal-border bg-terminal-surface p-6">
          <h2 className="text-xs uppercase tracking-wider text-terminal-text-muted mb-6 font-semibold flex items-center gap-2">
            <PlusCircle className="w-4 h-4" />
            LOG NEW TRADE
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
                Entry Price
              </label>
              <input
                type="number"
                data-testid="input-journal-entry-price"
                value={formData.entry_price}
                onChange={(e) => setFormData({ ...formData, entry_price: e.target.value })}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="50000"
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
                Stop Loss
              </label>
              <input
                type="number"
                data-testid="input-journal-stop-loss"
                value={formData.stop_loss}
                onChange={(e) => setFormData({ ...formData, stop_loss: e.target.value })}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="48000"
                step="0.01"
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
                Take Profit
              </label>
              <input
                type="text"
                data-testid="input-journal-take-profit"
                value={formData.take_profit}
                onChange={(e) => setFormData({ ...formData, take_profit: e.target.value })}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="52000"
              />
            </div>

            <div>
              <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-3">
                Result
              </label>
              <div className="flex gap-3">
                <button
                  type="button"
                  data-testid="result-win-button"
                  onClick={() => setFormData({ ...formData, result: 'win' })}
                  className={`flex-1 py-2 font-bold text-sm uppercase tracking-wider transition-colors ${
                    formData.result === 'win'
                      ? 'bg-terminal-green text-black'
                      : 'bg-transparent border border-terminal-border text-terminal-text hover:border-terminal-green'
                  }`}
                >
                  Win
                </button>
                <button
                  type="button"
                  data-testid="result-loss-button"
                  onClick={() => setFormData({ ...formData, result: 'loss' })}
                  className={`flex-1 py-2 font-bold text-sm uppercase tracking-wider transition-colors ${
                    formData.result === 'loss'
                      ? 'bg-terminal-danger text-white'
                      : 'bg-transparent border border-terminal-border text-terminal-text hover:border-terminal-danger'
                  }`}
                >
                  Loss
                </button>
              </div>
            </div>

            <button
              type="submit"
              data-testid="submit-trade-button"
              className="w-full py-3 bg-terminal-green text-black font-bold uppercase tracking-wider hover:bg-terminal-green-hover transition-colors"
            >
              LOG TRADE
            </button>
          </form>
        </div>
      </div>

      {/* Trades List */}
      <div className="lg:col-span-2">
        <div className="border border-terminal-border bg-terminal-surface p-6">
          <h2 className="text-xs uppercase tracking-wider text-terminal-text-muted mb-6 font-semibold">
            TRADE HISTORY ({trades.length})
          </h2>
          
          {loading ? (
            <div className="text-center text-terminal-text-muted py-8">Loading...</div>
          ) : trades.length === 0 ? (
            <div className="text-center text-terminal-text-muted py-8">
              No trades logged yet. Start by adding your first trade.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full font-mono text-sm">
                <thead>
                  <tr className="border-b border-terminal-border text-xs uppercase tracking-wider text-terminal-text-muted">
                    <th className="text-left py-3 px-2">Date/Time</th>
                    <th className="text-right py-3 px-2">Entry</th>
                    <th className="text-right py-3 px-2">Stop Loss</th>
                    <th className="text-right py-3 px-2">Take Profit</th>
                    <th className="text-center py-3 px-2">Result</th>
                  </tr>
                </thead>
                <tbody>
                  {trades.map((trade) => (
                    <tr
                      key={trade.id}
                      data-testid={`trade-row-${trade.id}`}
                      className="border-b border-terminal-border hover:bg-terminal-surface-hover transition-colors"
                    >
                      <td className="py-3 px-2 text-terminal-text-secondary">
                        {formatDate(trade.timestamp)}
                      </td>
                      <td className="text-right py-3 px-2 text-terminal-text">
                        ${parseFloat(trade.entry_price).toFixed(2)}
                      </td>
                      <td className="text-right py-3 px-2 text-terminal-text">
                        ${parseFloat(trade.stop_loss).toFixed(2)}
                      </td>
                      <td className="text-right py-3 px-2 text-terminal-text">
                        {trade.take_profit}
                      </td>
                      <td className="text-center py-3 px-2">
                        {trade.result === 'win' ? (
                          <span className="inline-flex items-center gap-1 text-terminal-green font-bold uppercase text-xs">
                            <TrendingUp className="w-3 h-3" />
                            WIN
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-terminal-danger font-bold uppercase text-xs">
                            <TrendingDown className="w-3 h-3" />
                            LOSS
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TradeJournal;