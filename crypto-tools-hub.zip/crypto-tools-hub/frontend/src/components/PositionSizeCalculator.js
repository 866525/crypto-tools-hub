import React, { useState, useEffect } from 'react';
import { DollarSign, Percent, TrendingUp, TrendingDown, AlertTriangle, AlertCircle } from 'lucide-react';

export const PositionSizeCalculator = () => {
  const [accountBalance, setAccountBalance] = useState('');
  const [riskPercentage, setRiskPercentage] = useState('1');
  const [entryPrice, setEntryPrice] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [positionSize, setPositionSize] = useState(null);
  const [flashKey, setFlashKey] = useState(0);
  const [riskWarning, setRiskWarning] = useState(null);

  useEffect(() => {
    // Validate risk percentage
    if (riskPercentage) {
      const risk = parseFloat(riskPercentage);
      if (risk > 10) {
        setRiskWarning({ type: 'error', message: '🔴 Danger: You may lose your account quickly' });
      } else if (risk > 5) {
        setRiskWarning({ type: 'warning', message: '⚠️ High risk - not recommended' });
      } else {
        setRiskWarning(null);
      }
    } else {
      setRiskWarning(null);
    }

    if (accountBalance && riskPercentage && entryPrice && stopLoss) {
      const balance = parseFloat(accountBalance);
      const risk = parseFloat(riskPercentage);
      const entry = parseFloat(entryPrice);
      const sl = parseFloat(stopLoss);

      if (balance > 0 && risk > 0 && entry > 0 && sl > 0 && entry !== sl) {
        const riskAmount = balance * (risk / 100);
        const priceRisk = Math.abs(entry - sl);
        const size = riskAmount / priceRisk;
        setPositionSize(size);
        setFlashKey(prev => prev + 1);
      } else {
        setPositionSize(null);
      }
    } else {
      setPositionSize(null);
    }
  }, [accountBalance, riskPercentage, entryPrice, stopLoss]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Input Section */}
      <div className="border border-terminal-border bg-terminal-surface p-6">
        <h2 className="text-xs uppercase tracking-wider text-terminal-text-muted mb-6 font-semibold">
          INPUT PARAMETERS
        </h2>
        
        <div className="space-y-5">
          <div>
            <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
              Account Balance (USD)
            </label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-terminal-text-muted" />
              <input
                type="number"
                data-testid="input-account-balance"
                value={accountBalance}
                onChange={(e) => setAccountBalance(e.target.value)}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 pl-10 pr-3 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="10000"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
              Risk Percentage (%)
            </label>
            <div className="relative">
              <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-terminal-text-muted" />
              <input
                type="number"
                data-testid="input-risk-percentage"
                value={riskPercentage}
                onChange={(e) => setRiskPercentage(e.target.value)}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 pl-10 pr-3 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="1"
                step="0.1"
              />
            </div>
            {riskWarning && (
              <div 
                data-testid={`risk-${riskWarning.type}`}
                className={`mt-3 px-3 py-2 border flex items-start gap-2 text-sm font-mono ${
                  riskWarning.type === 'error' 
                    ? 'border-terminal-danger bg-terminal-danger/10 text-terminal-danger' 
                    : 'border-terminal-warning bg-terminal-warning/10 text-terminal-warning'
                }`}
              >
                {riskWarning.type === 'error' ? (
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                )}
                <span>{riskWarning.message}</span>
              </div>
            )}
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
              Entry Price (USD)
            </label>
            <div className="relative">
              <TrendingUp className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-terminal-text-muted" />
              <input
                type="number"
                data-testid="input-entry-price"
                value={entryPrice}
                onChange={(e) => setEntryPrice(e.target.value)}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 pl-10 pr-3 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="50000"
                step="0.01"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
              Stop Loss (USD)
            </label>
            <div className="relative">
              <TrendingDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-terminal-text-muted" />
              <input
                type="number"
                data-testid="input-stop-loss"
                value={stopLoss}
                onChange={(e) => setStopLoss(e.target.value)}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 pl-10 pr-3 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="48000"
                step="0.01"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Output Section */}
      <div className="border border-terminal-border bg-terminal-surface p-6">
        <h2 className="text-xs uppercase tracking-wider text-terminal-text-muted mb-6 font-semibold">
          CALCULATED OUTPUT
        </h2>
        
        <div className="flex flex-col items-center justify-center h-[calc(100%-3rem)]">
          {positionSize !== null ? (
            <div className="text-center">
              <div className="text-xs uppercase tracking-wider text-terminal-text-muted mb-3">
                Position Size
              </div>
              <div
                key={flashKey}
                data-testid="output-position-size"
                className="text-5xl font-bold font-mono text-terminal-green terminal-glow calc-output-flash"
              >
                ${positionSize.toFixed(2)}
              </div>
              <div className="text-xs text-terminal-text-secondary mt-4">
                Risk Amount: ${((parseFloat(accountBalance) * parseFloat(riskPercentage)) / 100).toFixed(2)}
              </div>
            </div>
          ) : (
            <div className="text-center">
              <div className="text-terminal-text-muted text-sm">
                Enter all parameters to calculate
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PositionSizeCalculator;