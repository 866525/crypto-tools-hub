import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Target } from 'lucide-react';

export const TPSLCalculator = () => {
  const [entryPrice, setEntryPrice] = useState('');
  const [stopLoss, setStopLoss] = useState('');
  const [numTPs, setNumTPs] = useState(3);
  const [tpLevels, setTpLevels] = useState([]);
  const [flashKey, setFlashKey] = useState(0);

  const calculateTPLevels = () => {
    if (!entryPrice || !stopLoss) return [];

    const entry = parseFloat(entryPrice);
    const sl = parseFloat(stopLoss);

    if (entry <= 0 || sl <= 0 || entry === sl) return [];

    const isLong = entry > sl;
    const risk = Math.abs(entry - sl);

    const distributions = {
      2: [{ ratio: 1.5, allocation: 50 }, { ratio: 2.5, allocation: 50 }],
      3: [{ ratio: 1.5, allocation: 40 }, { ratio: 2.5, allocation: 30 }, { ratio: 3.5, allocation: 30 }],
      4: [{ ratio: 1.5, allocation: 30 }, { ratio: 2.5, allocation: 30 }, { ratio: 3.5, allocation: 30 }, { ratio: 5, allocation: 10 }]
    };

    const levels = distributions[numTPs].map((level, index) => {
      const tpPrice = isLong 
        ? entry + (risk * level.ratio)
        : entry - (risk * level.ratio);
      
      return {
        level: index + 1,
        price: tpPrice,
        allocation: level.allocation,
        ratio: level.ratio
      };
    });

    return levels;
  };

  useEffect(() => {
    const levels = calculateTPLevels();
    setTpLevels(levels);
    if (levels.length > 0) {
      setFlashKey(prev => prev + 1);
    }
  }, [entryPrice, stopLoss, numTPs]);

  const isLong = entryPrice && stopLoss && parseFloat(entryPrice) > parseFloat(stopLoss);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Input Section */}
      <div className="border border-terminal-border bg-terminal-surface p-6">
        <h2 className="text-xs uppercase tracking-wider text-terminal-text-muted mb-6 font-semibold">
          INPUT PARAMETERS
        </h2>
        
        <div className="space-y-5">
          <div>
            <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
              Entry Price (USD)
            </label>
            <div className="relative">
              <TrendingUp className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-terminal-text-muted" />
              <input
                type="number"
                data-testid="input-tpsl-entry-price"
                value={entryPrice}
                onChange={(e) => setEntryPrice(e.target.value)}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 pl-10 pr-3 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="50000"
                step="0.01"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
              Stop Loss (USD)
            </label>
            <div className="relative">
              <TrendingDown className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-terminal-text-muted" />
              <input
                type="number"
                data-testid="input-tpsl-stop-loss"
                value={stopLoss}
                onChange={(e) => setStopLoss(e.target.value)}
                className="w-full bg-transparent border-b border-terminal-border focus:border-terminal-green outline-none py-2 pl-10 pr-3 text-right font-mono text-terminal-text text-lg transition-colors"
                placeholder="48000"
                step="0.01"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs uppercase tracking-wider text-terminal-text-muted mb-3">
              Number of Take Profits
            </label>
            <div className="flex gap-3">
              {[2, 3, 4].map((num) => (
                <button
                  key={num}
                  data-testid={`tp-count-${num}`}
                  onClick={() => setNumTPs(num)}
                  className={`flex-1 py-3 font-mono font-bold text-lg transition-colors ${
                    numTPs === num
                      ? 'bg-terminal-green text-black'
                      : 'bg-transparent border border-terminal-border text-terminal-text hover:border-terminal-green'
                  }`}
                >
                  {num}
                </button>
              ))}
            </div>
          </div>

          {entryPrice && stopLoss && (
            <div className="pt-4 border-t border-terminal-border">
              <div className="text-xs uppercase tracking-wider text-terminal-text-muted mb-2">
                Position Type
              </div>
              <div className={`text-lg font-bold font-mono ${
                isLong ? 'text-terminal-green' : 'text-terminal-danger'
              }`}>
                {isLong ? 'LONG' : 'SHORT'}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Output Section */}
      <div className="border border-terminal-border bg-terminal-surface p-6">
        <h2 className="text-xs uppercase tracking-wider text-terminal-text-muted mb-6 font-semibold">
          TAKE PROFIT LEVELS
        </h2>
        
        {tpLevels.length > 0 ? (
          <div className="space-y-4" key={flashKey}>
            {tpLevels.map((tp) => (
              <div
                key={tp.level}
                data-testid={`tp-level-${tp.level}`}
                className="border border-terminal-border p-4 hover:border-terminal-green/50 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-terminal-green" />
                    <span className="text-xs uppercase tracking-wider text-terminal-text-muted">
                      TP {tp.level}
                    </span>
                  </div>
                  <span className="text-xs font-mono text-terminal-green">
                    {tp.allocation}%
                  </span>
                </div>
                <div className="font-mono text-2xl font-bold text-terminal-text calc-output-flash">
                  ${tp.price.toFixed(2)}
                </div>
                <div className="text-xs text-terminal-text-secondary mt-1">
                  {tp.ratio}R Risk-Reward
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center text-terminal-text-muted text-sm">
              Enter entry price and stop loss to calculate
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default TPSLCalculator;